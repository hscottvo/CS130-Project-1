./ray_tracer -i #1.txt -s #1.png

